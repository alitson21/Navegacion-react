function NoPage() {
    return (
        <div>
            <h1>404</h1>
            <p>Not Found</p>
        </div>
    )
}


export default NoPage;